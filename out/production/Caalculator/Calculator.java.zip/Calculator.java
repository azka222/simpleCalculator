import java.util.Scanner;

public class Calculator {
    static float total = 0;
    static void display(){
        System.out.println("Calculator");
        System.out.println("================");
        hasil();
    }
    static float hasil(){
        System.out.println("Total = " + total);
        return total;
    }
    static void input(){
        System.out.print("Input number :");
    }

    static void result(){
        display();
    }
    static float addition(float num1){
        Scanner keyboard = new Scanner(System.in);
        float num2;
        input();
        num2 = keyboard.nextFloat();
        total = total + num2;
        return total;
    }
    static float subtraction(float num1){
        Scanner keyboard = new Scanner(System.in);
        float num2;
        input();
        num2 = keyboard.nextFloat();
        total = total - num2;
        return total;
    }
    static float multiplication(float num1){
        Scanner keyboard = new Scanner(System.in);
        float num2;
        input();
        num2 = keyboard.nextFloat();
        total = total * num2;
        return total;
    }
    static float division(float num1){
        Scanner keyboard = new Scanner(System.in);
        float num2;
        input();
        num2 = keyboard.nextFloat();
        total = total / num2;
        return total;
    }
    static float modulo(float num1) {
        Scanner keyboard = new Scanner(System.in);
        float num2;
        input();
        num2 = keyboard.nextFloat();
        total = total % num2;
        return total;

    }
    static void menu(){
        System.out.println("1. Addition");
        System.out.println("2. Subtraction");
        System.out.println("3. Multiplication");
        System.out.println("4. Division");
        System.out.println("5. Modulo");
        System.out.println("6. Clear total");
        System.out.println("7. Exit");
    }


    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        display();
        float num1;
        input();
        num1 = keyboard.nextFloat();
        total = total + num1;
        menu();
        int ch = 0;
        while(ch != 7){
            System.out.print("Operator [1...7] : ");
            ch = keyboard.nextInt();

            if(ch == 1){
                addition(total);
                result();
            }
            else if (ch == 2) {
                subtraction(total);
                result();
            }
            else if (ch == 3) {
                multiplication(total);
                result();
            }
            else if (ch == 4) {
                division(total);
                result();
            }
            else if (ch == 5) {
                modulo(total);
                result();
            }
            else if (ch == 6) {
                total = 0;
                display();
                input();
                num1 = keyboard.nextFloat();
                total = total + num1;

            }

            else{
                System.out.println("Wrong Input!!");
            }
            menu();
        }
    }
}